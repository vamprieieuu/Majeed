#include "MajeedDitherEngine.h"
#include <algorithm>
#include <cmath>
#include <random>
#include <limits>

namespace Majeed {
static inline float sat(float v){return std::clamp(v,0.0f,1.0f);} 
static inline float lerp(float a,float b,float t){return a+(b-a)*t;}
float Luma(const PixelF&p){return 0.299f*p.r+0.587f*p.g+0.114f*p.b;}
static float hash(int x,int y,uint32_t s){ uint32_t n=(uint32_t)x*374761393u+(uint32_t)y*668265263u+s*1442695041u; n=(n^(n>>13))*1274126177u; n^=n>>16; return (n&0xffffff)/16777215.0f; }

const char* AlgorithmName(DitherAlgorithm a){
 switch(a){
 case DitherAlgorithm::FloydSteinberg:return "Floyd Steinberg"; case DitherAlgorithm::JarvisJudiceNinke:return "Jarvis-Judice-Ninke";
 case DitherAlgorithm::Stucki:return "Stucki"; case DitherAlgorithm::Burkes:return "Burkes"; case DitherAlgorithm::Atkinson:return "Atkinson";
 case DitherAlgorithm::RowModulation:return "Row Modulation"; case DitherAlgorithm::ColumnModulation:return "Column Modulation"; case DitherAlgorithm::DispersedModulation:return "Dispersed Modulation";
 case DitherAlgorithm::MediumModulation:return "Medium Modulation"; case DitherAlgorithm::HeavyModulation:return "Heavy Modulation"; case DitherAlgorithm::CircuitModulation:return "Circuit Modulation";
 case DitherAlgorithm::TiltModulation:return "Tilt Modulation"; case DitherAlgorithm::GridModulation:return "Grid Modulation"; case DitherAlgorithm::Sierra:return "Sierra";
 case DitherAlgorithm::SierraTwoRow:return "Sierra Two-Row"; case DitherAlgorithm::SierraLite:return "Sierra Lite"; case DitherAlgorithm::SkipNeighbours:return "Skip Neighbours";
 case DitherAlgorithm::Skip1Neighbours:return "Skip 1 Neighbours"; case DitherAlgorithm::Skip2Neighbours:return "Skip 2 Neighbours"; case DitherAlgorithm::Matrix:return "Matrix";
 case DitherAlgorithm::Knit:return "Knit"; case DitherAlgorithm::CrossSquare:return "Cross Square"; case DitherAlgorithm::Serpentine:return "Serpentine";
 case DitherAlgorithm::RektBlock:return "Rekt Block"; case DitherAlgorithm::VariableHatch:return "Variable Hatch"; case DitherAlgorithm::Bayer2:return "2x2 Bayer";
 case DitherAlgorithm::Bayer4:return "4x4 Bayer"; case DitherAlgorithm::Bayer8:return "8x8 Bayer"; case DitherAlgorithm::Halftone:return "Halftone";
 case DitherAlgorithm::Halftone225:return "Halftone 22.5°"; case DitherAlgorithm::Halftone45:return "Halftone 45°"; case DitherAlgorithm::Star:return "Star";
 case DitherAlgorithm::Grid:return "Grid"; case DitherAlgorithm::VerticalStitch:return "Vertical Stitch"; case DitherAlgorithm::HorizontalStitch:return "Horizontal Stitch";
 case DitherAlgorithm::Clock:return "Clock"; case DitherAlgorithm::Cyber:return "Cyber"; case DitherAlgorithm::BiThread:return "Bi-thread";
 case DitherAlgorithm::Bytewav:return "Bytewav"; case DitherAlgorithm::Bitslash:return "Bitslash"; case DitherAlgorithm::MosaicHalftone:return "Mosaic Halftone";
 case DitherAlgorithm::ZModulation:return "Z-Modulation"; case DitherAlgorithm::SquareHalftone:return "Square Halftone"; case DitherAlgorithm::HBeamModulation:return "H Beam Modulation";
 case DitherAlgorithm::VBeamModulation:return "V Beam Modulation"; case DitherAlgorithm::XeroxGrain:return "Xerox Grain"; }
 return "Unknown";
}
const char* ColorModeName(ColorMode m){return m==ColorMode::Tonal?"Tonal":m==ColorMode::Color?"Color":"Grade";}
const char* ColorSpaceName(ColorSpace c){return c==ColorSpace::Gray?"Gray":c==ColorSpace::RGB?"RGB":"Indexed";}

static void rgb2hsv(float r,float g,float b,float&h,float&s,float&v){float mx=std::max({r,g,b}),mn=std::min({r,g,b}),d=mx-mn;v=mx;s=mx?d/mx:0;if(!d)h=0;else if(mx==r)h=60*std::fmod((g-b)/d,6.0f);else if(mx==g)h=60*((b-r)/d+2);else h=60*((r-g)/d+4);if(h<0)h+=360;}
static PixelF hsv2rgb(float h,float s,float v,float a){float c=v*s,x=c*(1-std::fabs(std::fmod(h/60.0f,2)-1)),m=v-c;float r=0,g=0,b=0;int k=(int)std::floor(h/60);switch(k){case 0:r=c;g=x;break;case 1:r=x;g=c;break;case 2:g=c;b=x;break;case 3:g=x;b=c;break;case 4:r=x;b=c;break;default:r=c;b=x;}return {sat(r+m),sat(g+m),sat(b+m),a};}

static float bayer(int n,int x,int y){
 static const int b2[2][2]={{0,2},{3,1}};
 static const int b4[4][4]={{0,8,2,10},{12,4,14,6},{3,11,1,9},{15,7,13,5}};
 static const int b8[8][8]={{0,48,12,60,3,51,15,63},{32,16,44,28,35,19,47,31},{8,56,4,52,11,59,7,55},{40,24,36,20,43,27,39,23},{2,50,14,62,1,49,13,61},{34,18,46,30,33,17,45,29},{10,58,6,54,9,57,5,53},{42,26,38,22,41,25,37,21}};
 if(n==2)return (b2[y&1][x&1]+.5f)/4; if(n==4)return (b4[y&3][x&3]+.5f)/16; return (b8[y&7][x&7]+.5f)/64;
}

static float patternThreshold(DitherAlgorithm a,int x,int y){
 int ax=std::abs(x), ay=std::abs(y); float fx=(x&7)/8.0f, fy=(y&7)/8.0f;
 switch(a){
 case DitherAlgorithm::Bayer2:return bayer(2,x,y); case DitherAlgorithm::Bayer4:return bayer(4,x,y); case DitherAlgorithm::Bayer8:return bayer(8,x,y);
 case DitherAlgorithm::RowModulation:return ((x*37)&31)/32.0f;
 case DitherAlgorithm::ColumnModulation:return ((y*37)&31)/32.0f;
 case DitherAlgorithm::DispersedModulation:return (hash(x,y,17)+bayer(4,x,y))*0.5f;
 case DitherAlgorithm::MediumModulation:return (bayer(4,x*2,y*2)+bayer(4,x,y))*0.5f;
 case DitherAlgorithm::HeavyModulation:return (bayer(8,x,y)*0.65f+hash(x/2,y/2,9)*0.35f);
 case DitherAlgorithm::CircuitModulation:return ((x+y+(x*y&7))&15)/16.0f;
 case DitherAlgorithm::TiltModulation:return std::fmod((x+y)*0.073f,1.0f)+0.5f;
 case DitherAlgorithm::GridModulation:return (((x&3)==0)||((y&3)==0))?0.18f:0.82f;
 case DitherAlgorithm::ZModulation:return std::fmod((x*x+y*y)*0.03125f,1.0f);
 case DitherAlgorithm::Matrix:return ((x&3)==(y&3))?0.2f:0.8f;
 case DitherAlgorithm::Knit:return (((x+y)&1)?0.72f:0.28f);
 case DitherAlgorithm::CrossSquare:return ((x&3)==1||(y&3)==1)?0.25f:0.75f;
 case DitherAlgorithm::Serpentine:return ((y&1)?(x&7):((7-x)&7))/8.0f;
 case DitherAlgorithm::RektBlock:return ((x&3)==0&&(y&3)==0)?0.15f:0.85f;
 case DitherAlgorithm::VariableHatch:return (std::sin((x+y)*0.55f)*0.5f+0.5f);
 case DitherAlgorithm::Star:return (ax%3==0||ay%3==0||(ax+ay)%5==0)?0.25f:0.8f;
 case DitherAlgorithm::Grid:return ((x&3)==0||(y&3)==0)?0.2f:0.8f;
 case DitherAlgorithm::VerticalStitch:return (x&1)?0.25f:0.75f;
 case DitherAlgorithm::HorizontalStitch:return (y&1)?0.25f:0.75f;
 case DitherAlgorithm::Clock:return (std::atan2((float)y-3.5f,(float)x-3.5f)+3.14159265f)/(2*3.14159265f);
 case DitherAlgorithm::Cyber:return (std::fmod(std::abs(x*13+y*7),17))/17.0f;
 case DitherAlgorithm::BiThread:return ((x+y)&1)?0.2f:0.8f;
 case DitherAlgorithm::Bytewav:return (std::sin(x*0.9f)+std::sin(y*0.31f)+2)*0.25f;
 case DitherAlgorithm::Bitslash:return (((x-y)&7)/7.0f);
 default:return hash(x,y,1234);
 }
}

PixelF QuantizePixel(const PixelF&p,const DitherSettings&s){
 PixelF q=p;
 int n=std::max(2,s.tones);
 if(s.colorSpace==ColorSpace::Gray){float y=Luma(p); y=std::round(y*(n-1))/(n-1.0f); q={y,y,y,p.a};}
 else if(s.colorSpace==ColorSpace::Indexed && !s.palette.empty()){
   float best=1e30f; PaletteColor bc=s.palette[0];
   for(auto c:s.palette){float dr=p.r*255-c.r,dg=p.g*255-c.g,db=p.b*255-c.b,d=dr*dr+dg*dg+db*db;if(d<best){best=d;bc=c;}}
   q={(float)bc.r/255,(float)bc.g/255,(float)bc.b/255,p.a};
 } else {q.r=std::round(q.r*(n-1))/(n-1.0f);q.g=std::round(q.g*(n-1))/(n-1.0f);q.b=std::round(q.b*(n-1))/(n-1.0f);}
 return q;
}

struct Kernel { int radius; std::vector<std::array<int,3>> taps; int divisor; };
static Kernel diffusion(DitherAlgorithm a){
 switch(a){
 case DitherAlgorithm::FloydSteinberg:return {1,{{1,0,7},{-1,1,3},{0,1,5},{1,1,1}},16};
 case DitherAlgorithm::JarvisJudiceNinke:return {2,{{1,0,7},{2,0,5},{-2,1,3},{-1,1,5},{0,1,7},{1,1,5},{2,1,3},{-2,2,1},{-1,2,3},{0,2,5},{1,2,3},{2,2,1}},48};
 case DitherAlgorithm::Stucki:return {2,{{1,0,8},{2,0,4},{-2,1,2},{-1,1,4},{0,1,8},{1,1,4},{2,1,2},{-2,2,1},{-1,2,2},{0,2,4},{1,2,2},{2,2,1}},42};
 case DitherAlgorithm::Burkes:return {2,{{1,0,8},{2,0,4},{-2,1,2},{-1,1,4},{0,1,8},{1,1,4},{2,1,2}},32};
 case DitherAlgorithm::Atkinson:return {2,{{1,0,1},{2,0,1},{-1,1,1},{0,1,1},{1,1,1},{0,2,1}},8};
 case DitherAlgorithm::Sierra:return {2,{{1,0,5},{2,0,3},{-2,1,2},{-1,1,4},{0,1,5},{1,1,4},{2,1,2},{-1,2,2},{0,2,3},{1,2,2}},32};
 case DitherAlgorithm::SierraTwoRow:return {2,{{1,0,4},{2,0,3},{-2,1,1},{-1,1,2},{0,1,3},{1,1,2},{2,1,1}},16};
 case DitherAlgorithm::SierraLite:return {1,{{1,0,2},{-1,1,1},{0,1,1}},4};
 default:return {};
 }}

void ApplyPreGrade(Image& img,const DitherSettings&s,uint32_t seed){
 // Mirrors the source UI's preprocessing controls: noise, blur/sharp, grade bias,
 // hue/saturation/invert and color-space preparation.
 if(s.noise!=0){ for(int y=0;y<img.height;y++)for(int x=0;x<img.width;x++){auto&p=img.at(x,y);float n=(hash(x,y,seed)-.5f)*(s.noise/50.0f);p.r=sat(p.r+n);p.g=sat(p.g+n);p.b=sat(p.b+n);} }
 if(s.blur>0){ Image tmp=img; int r=std::max(1,(int)std::round(s.blur/6)); for(int y=0;y<img.height;y++)for(int x=0;x<img.width;x++){PixelF z{};int c=0;for(int yy=-r;yy<=r;yy++)for(int xx=-r;xx<=r;xx++){int X=std::clamp(x+xx,0,img.width-1),Y=std::clamp(y+yy,0,img.height-1);auto q=tmp.at(X,Y);z.r+=q.r;z.g+=q.g;z.b+=q.b;z.a+=q.a;c++;}z.r/=c;z.g/=c;z.b/=c;z.a/=c;img.at(x,y)=z;} }
 if(s.sharpStrength>0){Image tmp=img;float k=s.sharpStrength*0.35f;int r=std::max(1,(int)std::round(s.sharpRadius));for(int y=0;y<img.height;y++)for(int x=0;x<img.width;x++){auto p=tmp.at(x,y),n=tmp.at(std::clamp(x+r,0,img.width-1),y),w=tmp.at(std::clamp(x-r,0,img.width-1),y),u=tmp.at(x,std::clamp(y-r,0,img.height-1)),d=tmp.at(x,std::clamp(y+r,0,img.height-1));p.r=sat(p.r+k*(4*p.r-n.r-w.r-u.r-d.r));p.g=sat(p.g+k*(4*p.g-n.g-w.g-u.g-d.g));p.b=sat(p.b+k*(4*p.b-n.b-w.b-u.b-d.b));img.at(x,y)=p;}}
 for(auto&p:img.pixels){float h,ss,v;rgb2hsv(p.r,p.g,p.b,h,ss,v);h=std::fmod(h+s.hue+360,360.0f);ss=sat(ss*(1+s.saturation/100.0f));p=hsv2rgb(h,ss,v,p.a);p.r=lerp(p.r,1-p.r,s.invert/100.0f);p.g=lerp(p.g,1-p.g,s.invert/100.0f);p.b=lerp(p.b,1-p.b,s.invert/100.0f);}
}

void ApplyDither(Image& img,const DitherSettings&s,uint32_t seed){
 const int step=std::max(1,(int)std::round(s.scale));
 if((int)s.algorithm<=5 || (int)s.algorithm>=14 && (int)s.algorithm<=16 || (int)s.algorithm>=17 && (int)s.algorithm<=19){
   Kernel k=diffusion(s.algorithm); if(k.taps.empty()) return;
   std::vector<PixelF> work=img.pixels;
   auto W=[&](int x,int y)->PixelF&{return work[(size_t)y*img.width+x];};
   for(int y=0;y<img.height;y++){
     bool rev=(s.algorithm==DitherAlgorithm::Serpentine)&&(y&1);
     for(int xi=0;xi<img.width;xi++){
       int x=rev?img.width-1-xi:xi; PixelF old=W(x,y); PixelF q=QuantizePixel(old,s); W(x,y)=q; float er=(old.r-q.r)*s.amount,eg=(old.g-q.g)*s.amount,eb=(old.b-q.b)*s.amount;
       for(auto t:k.taps){int nx=x+t[0],ny=y+t[1];if(nx>=0&&nx<img.width&&ny>=0&&ny<img.height){auto&z=W(nx,ny);float f=(float)t[2]/k.divisor;z.r=sat(z.r+er*f);z.g=sat(z.g+eg*f);z.b=sat(z.b+eb*f);}}
     }
   }
   img.pixels=std::move(work); return;
 }
 // Pattern / halftone families. Downsample conceptually through scale, then threshold each cell.
 Image src=img;
 for(int y=0;y<img.height;y++)for(int x=0;x<img.width;x++){
   auto p=src.at(x,y); float lum=Luma(p); float t=patternThreshold(s.algorithm,x/step,y/step);
   if((int)s.algorithm>=29 && (int)s.algorithm<=31 || s.algorithm==DitherAlgorithm::MosaicHalftone || s.algorithm==DitherAlgorithm::SquareHalftone || s.algorithm==DitherAlgorithm::XeroxGrain){
     float ang=s.algorithm==DitherAlgorithm::Halftone225?3.14159265f/8:s.algorithm==DitherAlgorithm::Halftone45?3.14159265f/4:0;float cx=x-std::cos(ang)*x-std::sin(ang)*y,cy=std::sin(ang)*x+std::cos(ang)*y;float d=std::fmod(std::sqrt(cx*cx+cy*cy),step*2.0f)/(step*2.0f);t=d;
   }
   float v=lum>=t?1.0f:0.0f; PixelF q;
   if(s.colorSpace==ColorSpace::Gray||s.mode==ColorMode::Tonal) q={v,v,v,p.a}; else {q={p.r>=t?1.f:0.f,p.g>=t?1.f:0.f,p.b>=t?1.f:0.f,p.a};}
   float a=sat(s.amount); img.at(x,y).r=lerp(p.r,q.r,a);img.at(x,y).g=lerp(p.g,q.g,a);img.at(x,y).b=lerp(p.b,q.b,a);
 }
}

void ApplyPostGrade(Image&img,const DitherSettings&s){
 float bias=s.gradeBias/100.0f; for(auto&p:img.pixels){p.r=sat(p.r+bias*(p.r-.5f));p.g=sat(p.g+bias*(p.g-.5f));p.b=sat(p.b+bias*(p.b-.5f));}
}
}
