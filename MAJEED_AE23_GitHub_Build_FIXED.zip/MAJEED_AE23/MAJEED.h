#pragma once

// MAJEED - Native Adobe After Effects effect
// The Adobe After Effects 23 SDK is required to compile this source.
// Do not rename this file or the resulting binary manually.

#include "AEConfig.h"
#include "entry.h"
#include "AE_Effect.h"
#include "AE_EffectCB.h"
#include "Param_Utils.h"
#include "String_Utils.h"

#define MAJEED_NAME "MAJEED"
#define MAJEED_MATCH_NAME "MAJEED"
#define MAJEED_MAJOR_VERSION 1
#define MAJEED_MINOR_VERSION 0
#define MAJEED_BUG_VERSION 0
#define MAJEED_STAGE_VERSION PF_Stage_Version
#define MAJEED_RESERVED 0

enum {
    MAJEED_INPUT = 0,
    MAJEED_AMOUNT,
    MAJEED_DITHER,
    MAJEED_DITHER_SIZE,
    MAJEED_DITHER_CONTRAST,
    MAJEED_DITHER_SEED,
    MAJEED_GRAIN,
    MAJEED_GRAIN_SIZE,
    MAJEED_GRAIN_AMOUNT,
    MAJEED_GRAIN_CONTRAST,
    MAJEED_GRAIN_SOFTNESS,
    MAJEED_GRAIN_SEED,
    MAJEED_PRINT,
    MAJEED_PRINT_DENSITY,
    MAJEED_PRINT_BLEED,
    MAJEED_PRINT_OFFSET,
    MAJEED_FILM,
    MAJEED_FILM_CONTRAST,
    MAJEED_FILM_FADE,
    MAJEED_TEXTURE,
    MAJEED_TEXTURE_AMOUNT,
    MAJEED_DUST,
    MAJEED_DUST_AMOUNT,
    MAJEED_OUTPUT,
    MAJEED_NUM_PARAMS
};

extern "C" DllExport
PF_Err EffectMain(
    PF_Cmd cmd,
    PF_InData* in_data,
    PF_OutData* out_data,
    PF_ParamDef* params[],
    PF_LayerDef* output);

PF_Err About(PF_InData*, PF_OutData*, PF_ParamDef*[], PF_LayerDef*);
PF_Err GlobalSetup(PF_InData*, PF_OutData*);
PF_Err ParamsSetup(PF_InData*, PF_OutData*, PF_ParamDef*[]);
PF_Err Render(PF_InData*, PF_OutData*, PF_ParamDef*[], PF_LayerDef*);

namespace Majeed {

struct Pixel {
    float r, g, b, a;
};

struct Settings {
    float amount;
    float dither;
    float ditherSize;
    float ditherContrast;
    int ditherSeed;

    float grain;
    float grainSize;
    float grainContrast;
    float grainSoftness;
    int grainSeed;

    float print;
    float printDensity;
    float printBleed;
    float printOffset;

    float film;
    float filmContrast;
    float filmFade;

    float texture;
    float textureAmount;

    float dust;
    float dustAmount;
};

float clamp01(float v);
float hash(float x, float y, float seed);
float noise(float x, float y, float seed);

Pixel ApplyFilm(Pixel p, const Settings& s);
Pixel ApplyPrint(Pixel p, float x, float y, const Settings& s);
Pixel ApplyDither(Pixel p, float x, float y, const Settings& s);
Pixel ApplyTexture(Pixel p, float x, float y, const Settings& s);
Pixel ApplyGrain(Pixel p, float x, float y, const Settings& s);
Pixel ApplyDust(Pixel p, float x, float y, const Settings& s);

Pixel ProcessPixel(Pixel p, float x, float y, const Settings& s);

} // namespace Majeed
