#include "Majeed.h"
#include <cmath>
#include <algorithm>

static const char* kDescription =
    "MAJEED - Film, Print, Dither, Grain and Texture Engine";

#define MAJEED_VERSION_MAJOR 1
#define MAJEED_VERSION_MINOR 0
#define MAJEED_VERSION_BUG   0

extern "C" DllExport
PF_Err EffectMain(
    PF_Cmd cmd,
    PF_InData* in_data,
    PF_OutData* out_data,
    PF_ParamDef* params[],
    PF_LayerDef* output)
{
    switch (cmd) {
        case PF_Cmd_ABOUT:
            return About(in_data, out_data, params, output);

        case PF_Cmd_GLOBAL_SETUP:
            return GlobalSetup(in_data, out_data);

        case PF_Cmd_PARAMS_SETUP:
            return ParamsSetup(in_data, out_data, params);

        case PF_Cmd_RENDER:
            return Render(in_data, out_data, params, output);

        default:
            return PF_Err_NONE;
    }
}

PF_Err About(
    PF_InData*,
    PF_OutData* out_data,
    PF_ParamDef*[],
    PF_LayerDef*)
{
    out_data->return_msg = kDescription;
    return PF_Err_NONE;
}

PF_Err GlobalSetup(
    PF_InData* in_data,
    PF_OutData* out_data)
{
    out_data->my_version =
        PF_VERSION(MAJEED_VERSION_MAJOR,
                   MAJEED_VERSION_MINOR,
                   MAJEED_VERSION_BUG,
                   0,
                   0);

    out_data->out_flags =
        PF_OutFlag_DEEP_COLOR_AWARE |
        PF_OutFlag_USE_OUTPUT_EXTENT |
        PF_OutFlag_PIX_INDEPENDENT;

    // Adobe's MFR-safe flag is enabled only when the implementation
    // is completely free of shared mutable state.
    out_data->out_flags2 =
        PF_OutFlag2_SUPPORTS_THREADED_RENDERING;

    return PF_Err_NONE;
}

static void AddSlider(
    PF_ParamDef* def,
    const char* name,
    PF_Fixed value,
    PF_Fixed minValue,
    PF_Fixed maxValue)
{
    AEFX_CLR_STRUCT(*def);
    PF_ADD_SLIDER(
        name,
        minValue,
        maxValue,
        minValue,
        maxValue,
        value,
        0,
        0,
        0,
        0,
        0);
}

PF_Err ParamsSetup(
    PF_InData*,
    PF_OutData* out_data,
    PF_ParamDef* params[])
{
    AEFX_CLR_STRUCT(params[MAJEED_AMOUNT]);
    PF_ADD_SLIDER("Master Amount", 0, 100, 0, 100, 100, 0, 0, 0, 0, MAJEED_AMOUNT);

    AEFX_CLR_STRUCT(params[MAJEED_DITHER]);
    PF_ADD_SLIDER("Dither", 0, 100, 0, 100, 0, 0, 0, 0, 0, MAJEED_DITHER);

    AEFX_CLR_STRUCT(params[MAJEED_DITHER_SIZE]);
    PF_ADD_SLIDER("Dither Size", 1, 32, 1, 32, 4, 0, 0, 0, 0, MAJEED_DITHER_SIZE);

    AEFX_CLR_STRUCT(params[MAJEED_DITHER_CONTRAST]);
    PF_ADD_SLIDER("Dither Contrast", 0, 200, 0, 200, 100, 0, 0, 0, 0, MAJEED_DITHER_CONTRAST);

    AEFX_CLR_STRUCT(params[MAJEED_DITHER_SEED]);
    PF_ADD_SLIDER("Dither Seed", 0, 10000, 0, 10000, 0, 0, 0, 0, 0, MAJEED_DITHER_SEED);

    AEFX_CLR_STRUCT(params[MAJEED_GRAIN]);
    PF_ADD_SLIDER("Grain", 0, 100, 0, 100, 0, 0, 0, 0, 0, MAJEED_GRAIN);

    AEFX_CLR_STRUCT(params[MAJEED_GRAIN_SIZE]);
    PF_ADD_SLIDER("Grain Size", 1, 100, 1, 100, 18, 0, 0, 0, 0, MAJEED_GRAIN_SIZE);

    AEFX_CLR_STRUCT(params[MAJEED_GRAIN_AMOUNT]);
    PF_ADD_SLIDER("Grain Amount", 0, 100, 0, 100, 40, 0, 0, 0, 0, MAJEED_GRAIN_AMOUNT);

    AEFX_CLR_STRUCT(params[MAJEED_GRAIN_CONTRAST]);
    PF_ADD_SLIDER("Grain Contrast", 0, 200, 0, 200, 100, 0, 0, 0, 0, MAJEED_GRAIN_CONTRAST);

    AEFX_CLR_STRUCT(params[MAJEED_GRAIN_SOFTNESS]);
    PF_ADD_SLIDER("Grain Softness", 0, 100, 0, 100, 30, 0, 0, 0, 0, MAJEED_GRAIN_SOFTNESS);

    AEFX_CLR_STRUCT(params[MAJEED_GRAIN_SEED]);
    PF_ADD_SLIDER("Grain Seed", 0, 10000, 0, 10000, 0, 0, 0, 0, 0, MAJEED_GRAIN_SEED);

    AEFX_CLR_STRUCT(params[MAJEED_PRINT]);
    PF_ADD_SLIDER("Print", 0, 100, 0, 100, 0, 0, 0, 0, 0, MAJEED_PRINT);

    AEFX_CLR_STRUCT(params[MAJEED_PRINT_DENSITY]);
    PF_ADD_SLIDER("Ink Density", 0, 100, 0, 100, 50, 0, 0, 0, 0, MAJEED_PRINT_DENSITY);

    AEFX_CLR_STRUCT(params[MAJEED_PRINT_BLEED]);
    PF_ADD_SLIDER("Ink Bleed", 0, 100, 0, 100, 10, 0, 0, 0, 0, MAJEED_PRINT_BLEED);

    AEFX_CLR_STRUCT(params[MAJEED_PRINT_OFFSET]);
    PF_ADD_SLIDER("Registration Offset", -20, 20, -20, 20, 0, 0, 0, 0, 0, MAJEED_PRINT_OFFSET);

    AEFX_CLR_STRUCT(params[MAJEED_FILM]);
    PF_ADD_SLIDER("Film", 0, 100, 0, 100, 0, 0, 0, 0, 0, MAJEED_FILM);

    AEFX_CLR_STRUCT(params[MAJEED_FILM_CONTRAST]);
    PF_ADD_SLIDER("Film Contrast", 0, 200, 0, 200, 100, 0, 0, 0, 0, MAJEED_FILM_CONTRAST);

    AEFX_CLR_STRUCT(params[MAJEED_FILM_FADE]);
    PF_ADD_SLIDER("Fade", 0, 100, 0, 100, 0, 0, 0, 0, 0, MAJEED_FILM_FADE);

    AEFX_CLR_STRUCT(params[MAJEED_TEXTURE]);
    PF_ADD_SLIDER("Texture", 0, 100, 0, 100, 0, 0, 0, 0, 0, MAJEED_TEXTURE);

    AEFX_CLR_STRUCT(params[MAJEED_TEXTURE_AMOUNT]);
    PF_ADD_SLIDER("Texture Amount", 0, 100, 0, 100, 25, 0, 0, 0, 0, MAJEED_TEXTURE_AMOUNT);

    AEFX_CLR_STRUCT(params[MAJEED_DUST]);
    PF_ADD_SLIDER("Dust & Scratch", 0, 100, 0, 100, 0, 0, 0, 0, 0, MAJEED_DUST);

    AEFX_CLR_STRUCT(params[MAJEED_DUST_AMOUNT]);
    PF_ADD_SLIDER("Dust Amount", 0, 100, 0, 100, 20, 0, 0, 0, 0, MAJEED_DUST_AMOUNT);

    out_data->num_params = MAJEED_NUM_PARAMS;
    return PF_Err_NONE;
}

namespace Majeed {

float clamp01(float v)
{
    return std::max(0.0f, std::min(1.0f, v));
}

float hash(float x, float y, float seed)
{
    float n = std::sin(x * 12.9898f + y * 78.233f + seed * 37.719f) * 43758.5453f;
    return n - std::floor(n);
}

float noise(float x, float y, float seed)
{
    // Small deterministic value noise. It is deliberately stateless,
    // making the operation suitable for threaded/MFR rendering.
    float x0 = std::floor(x);
    float y0 = std::floor(y);
    float fx = x - x0;
    float fy = y - y0;

    float a = hash(x0,     y0,     seed);
    float b = hash(x0 + 1, y0,     seed);
    float c = hash(x0,     y0 + 1, seed);
    float d = hash(x0 + 1, y0 + 1, seed);

    float ux = fx * fx * (3.0f - 2.0f * fx);
    float uy = fy * fy * (3.0f - 2.0f * fy);

    float ab = a + (b - a) * ux;
    float cd = c + (d - c) * ux;
    return ab + (cd - ab) * uy;
}

Pixel ApplyFilm(Pixel p, const Settings& s)
{
    if (s.film <= 0.0f) return p;

    float c = 0.5f + (s.filmContrast * 0.005f) * (0.5f - 0.5f);
    (void)c;

    float k = s.filmContrast / 100.0f;
    p.r = clamp01((p.r - 0.5f) * k + 0.5f);
    p.g = clamp01((p.g - 0.5f) * k + 0.5f);
    p.b = clamp01((p.b - 0.5f) * k + 0.5f);

    // Gentle black lift / faded print response.
    float fade = s.filmFade / 100.0f;
    p.r = p.r * (1.0f - fade) + fade * 0.018f;
    p.g = p.g * (1.0f - fade) + fade * 0.018f;
    p.b = p.b * (1.0f - fade) + fade * 0.018f;

    return p;
}

Pixel ApplyPrint(Pixel p, float x, float y, const Settings& s)
{
    if (s.print <= 0.0f) return p;

    float n = noise(x * 0.07f, y * 0.07f, 17.0f);
    float density = s.printDensity / 100.0f;
    float bleed = s.printBleed / 100.0f;

    float shift = (n - 0.5f) * bleed * 0.12f;

    p.r = clamp01(p.r * (1.0f - density * 0.10f) + shift);
    p.g = clamp01(p.g * (1.0f - density * 0.08f) + shift);
    p.b = clamp01(p.b * (1.0f - density * 0.06f) + shift);

    return p;
}

Pixel ApplyDither(Pixel p, float x, float y, const Settings& s)
{
    if (s.dither <= 0.0f) return p;

    float size = std::max(1.0f, s.ditherSize);
    float bx = std::floor(x / size);
    float by = std::floor(y / size);

    // Bayer 4x4 ordered threshold.
    static const int bayer[4][4] = {
        { 0,  8,  2, 10},
        {12,  4, 14,  6},
        { 3, 11,  1,  9},
        {15,  7, 13,  5}
    };

    int ix = ((int)bx) & 3;
    int iy = ((int)by) & 3;

    float threshold = (bayer[iy][ix] + 0.5f) / 16.0f;
    float lum = 0.2126f * p.r + 0.7152f * p.g + 0.0722f * p.b;

    float contrast = s.ditherContrast / 100.0f;
    lum = clamp01((lum - 0.5f) * contrast + 0.5f);

    float d = s.dither / 100.0f;
    float binary = lum >= threshold ? 1.0f : 0.0f;
    float value = lum * (1.0f - d) + binary * d;

    p.r = p.g = p.b = value;
    return p;
}

Pixel ApplyTexture(Pixel p, float x, float y, const Settings& s)
{
    if (s.texture <= 0.0f) return p;

    float n1 = noise(x * 0.035f, y * 0.035f, 51.0f);
    float n2 = noise(x * 0.15f,  y * 0.15f,  73.0f);
    float t = (n1 * 0.7f + n2 * 0.3f) - 0.5f;
    t *= (s.textureAmount / 100.0f) * (s.texture / 100.0f);

    p.r = clamp01(p.r + t);
    p.g = clamp01(p.g + t);
    p.b = clamp01(p.b + t);

    return p;
}

Pixel ApplyGrain(Pixel p, float x, float y, const Settings& s)
{
    if (s.grain <= 0.0f) return p;

    float scale = std::max(0.5f, s.grainSize * 0.08f);

    // Multi-frequency grain gives a less uniform result than a single
    // Add Noise operation.
    float fine = noise(x / scale, y / scale, (float)s.grainSeed);
    float mid  = noise(x / (scale * 2.7f), y / (scale * 2.7f),
                       (float)s.grainSeed + 101.0f);

    float g = (fine * 0.72f + mid * 0.28f) - 0.5f;

    float contrast = s.grainContrast / 100.0f;
    g *= contrast * (s.grainAmount / 100.0f) * (s.grain / 100.0f);

    // Slight luminance dependence: grain remains visible but is naturally
    // reduced at absolute black/white.
    float lum = 0.2126f * p.r + 0.7152f * p.g + 0.0722f * p.b;
    float response = 0.45f + 0.55f * (1.0f - std::abs(lum * 2.0f - 1.0f));

    g *= response;

    float softness = s.grainSoftness / 100.0f;
    g *= 1.0f - softness * 0.35f;

    p.r = clamp01(p.r + g);
    p.g = clamp01(p.g + g);
    p.b = clamp01(p.b + g);

    return p;
}

Pixel ApplyDust(Pixel p, float x, float y, const Settings& s)
{
    if (s.dust <= 0.0f) return p;

    float n = noise(x * 0.018f, y * 0.018f, 901.0f + s.dustAmount);

    // Sparse dark/light imperfections.
    float strength = (s.dust / 100.0f) * (s.dustAmount / 100.0f);

    if (n > 0.992f) {
        p.r *= (1.0f - 0.35f * strength);
        p.g *= (1.0f - 0.35f * strength);
        p.b *= (1.0f - 0.35f * strength);
    }

    return p;
}

Pixel ProcessPixel(Pixel p, float x, float y, const Settings& s)
{
    // Fixed MAJEED pipeline:
    // Input -> Film -> Print -> Dither -> Texture -> Grain -> Dust -> Output
    p = ApplyFilm(p, s);
    p = ApplyPrint(p, x, y, s);
    p = ApplyDither(p, x, y, s);
    p = ApplyTexture(p, x, y, s);
    p = ApplyGrain(p, x, y, s);
    p = ApplyDust(p, x, y, s);
    return p;
}

} // namespace Majeed

PF_Err Render(
    PF_InData*,
    PF_OutData*,
    PF_ParamDef*[],
    PF_LayerDef*)
{
    // The actual AE pixel-format dispatch and SmartFX/MFR render path
    // is connected after the AE 23 SDK is present.
    //
    // Keeping this layer separate lets the MAJEED processing engine above
    // remain independent from Adobe's SDK structures.
    return PF_Err_NONE;
}
