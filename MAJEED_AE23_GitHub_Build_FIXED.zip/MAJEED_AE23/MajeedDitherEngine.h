#pragma once
#include <vector>
#include <array>
#include <cstdint>
#include <string>

namespace Majeed {

enum class DitherAlgorithm : int {
    FloydSteinberg=1, JarvisJudiceNinke=2, Stucki=3, Burkes=4, Atkinson=5,
    RowModulation=6, ColumnModulation=7, DispersedModulation=8, MediumModulation=9,
    HeavyModulation=10, CircuitModulation=11, TiltModulation=12, GridModulation=13,
    Sierra=14, SierraTwoRow=15, SierraLite=16, SkipNeighbours=17, Skip1Neighbours=18,
    Skip2Neighbours=19, Matrix=20, Knit=21, CrossSquare=22, Serpentine=23,
    RektBlock=24, VariableHatch=25, Bayer2=26, Bayer4=27, Bayer8=28,
    Halftone=29, Halftone225=30, Halftone45=31, Star=32, Grid=33,
    VerticalStitch=34, HorizontalStitch=35, Clock=36, Cyber=37, BiThread=38,
    Bytewav=39, Bitslash=40, MosaicHalftone=41, ZModulation=42, SquareHalftone=44,
    HBeamModulation=45, VBeamModulation=46, XeroxGrain=47
};

enum class ColorMode { Tonal=1, Color=2, Grade=3 };
enum class ColorSpace { Gray=0, RGB=1, Indexed=2 };
enum class Resampling { Nearest=0, PreserveDetails=1 };

enum class GradePreset {
    None, RetroBalanced, RetroBright, RetroDark, RetroFaded, RetroPrint, RetroRed,
    RetroSaturation, Soft, Screenprint
};

struct PixelF { float r=0,g=0,b=0,a=1; };
struct PaletteColor { uint8_t r=0,g=0,b=0; };

struct DitherSettings {
    DitherAlgorithm algorithm=DitherAlgorithm::FloydSteinberg;
    ColorMode mode=ColorMode::Tonal;
    ColorSpace colorSpace=ColorSpace::RGB;
    int inputDPI=300;
    float scale=4.0f;
    float amount=1.0f;
    float noise=0.0f;
    float blur=0.0f;
    float sharpStrength=1.0f;
    float sharpRadius=1.0f;
    int tones=2;
    int indexColors=8;
    float spread=100.0f;
    float gradeBias=0.0f;
    float hue=0.0f;
    float saturation=0.0f;
    float invert=0.0f;
    float bleed=0.0f;
    float offset=0.0f;
    bool rounding=false;
    bool autoNormalizeDPI=true;
    bool linkDPIScale=true;
    bool fadeDots=false;
    bool fadeLines=false;
    Resampling resampling=Resampling::Nearest;
    std::vector<PaletteColor> palette;
};

struct Image {
    int width=0,height=0,channels=3;
    std::vector<PixelF> pixels;
    PixelF& at(int x,int y) { return pixels[(size_t)y*width+x]; }
    const PixelF& at(int x,int y) const { return pixels[(size_t)y*width+x]; }
};

const char* AlgorithmName(DitherAlgorithm a);
const char* ColorModeName(ColorMode m);
const char* ColorSpaceName(ColorSpace c);

void ApplyPreGrade(Image& img, const DitherSettings& s, uint32_t seed=0);
void ApplyDither(Image& img, const DitherSettings& s, uint32_t seed=0);
void ApplyPostGrade(Image& img, const DitherSettings& s);

PixelF QuantizePixel(const PixelF& p, const DitherSettings& s);
float Luma(const PixelF& p);

} // namespace Majeed
