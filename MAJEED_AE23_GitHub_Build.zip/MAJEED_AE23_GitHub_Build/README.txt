MAJEED AE23 - GitHub Actions build package

1. Keep this repository PRIVATE because it contains the Adobe After Effects SDK files.
2. Upload this folder to a private GitHub repository.
3. Open Actions -> Build MAJEED AE23 -> Run workflow.
4. After the workflow finishes, open the run and download artifact: MAJEED-AE23-x64.

Important:
- This workflow only builds the current source.
- The current MAJEED Render() function is a stub and returns PF_Err_NONE. Therefore the resulting AEX may load but does not yet process AE pixels.
- The next coding step is to connect Majeed::ProcessPixel() to the AE 23 render path.
